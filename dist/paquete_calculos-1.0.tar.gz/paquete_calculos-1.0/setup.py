from setuptools import setup

setup(
	name="paquete_calculos",
	version="1.0",
	description="Paquete de redondeo y potencia.",
	author="Villal",
	author_email="masterpichula360@hotmail.com",
	url="www.elvillalhackerman.com.ar",
	packages=["calculos","calculos.redondeo_potencia"]
	)